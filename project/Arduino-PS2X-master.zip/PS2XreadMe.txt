Hey guys. I have packed this ZIP file for you so you do not have to go 
searching for software and Libraries.

ZIP Content Description:

"Arduino-PS2X-master" This is the LIBRARY folder. Click this folder and 
		      EXTRACT TO your specific arduino library folder.
		      Ex.  C://Users/JohnDoe/Programs/arduino1.0.x/libraries
		      This destination is different for everyone. This is
		      where you originally downloaded your Arduino Program(IDE)
		      Once you extracted to the libraries folder, Go to that
		      folder and RENAME IT FROM: 
			"Arduino-PS2X-master" TO "PS2X_lib" : 
		      this will lower the chances of library related compile
		      errors. Now open the 
		      Arduino program and check under 
			      Sketch > Import Library > PS2X_lib  

			~Bingo! You now should see this ^^^^^^^^^^ in your 
			Arduino Program! Library Install Successful~!
"PS2DpadLED_OdinExample"
			
			This is the modified sketch that you see me using 
			in the tutorial. If you want to use the LEDs as seen
			in the tut, open this sketch after the library install
			
	      ~NOTE:~   For a clean copy of the example (Unmodified), navigate
			to the Library install folder (where you just extracted
			the library to) :
				 arduino1.0.x/libraries/PS2X_lib/Examples 
			In this Examples folder you will find the ORIGINAL .ino
			file by Bill Porter. Thanks Bill for providing us this
			solid sketch! 
			(Original sketch also here) :
			Open Arduino Program, then click
			File > Examples > PS2X_lib > PS2X_Example <<<<<<
			(must install library first for this to appear^^)
			

"PS2 Controller PIN 
OUT Guide.jpg"
			This is what you will need to identify the PS2 Controller
			header Pins (the part that plugs into the PS2 Console)
			Keep this image open as you work so you can quickly 
			reference it! (it comes in handy) Again all provided
			by Bill Porter and CuriousInventor.com ! I just 
			packed them into this ZIP for convenience.

FOR MORE HELP CHECK http://forum.arduino.cc/index.php?topic=102901.0  

I have spent many hours creating this Tutorial for everyone ! Please let me
know if it was helpful! I am looking forward to seeing what people can control
will this PS2 controller as a transmitter! I also have other advanced PS2 
Transmitter sketches that incorporate wireless (NRF24L01 2.4Ghz) and other 
cool sketches I have found online whilst researching this project. One of specific
interest includes using this controller as an RC transmitter (joystick-ppm) 
however these sketches are rough and need some modification before they become
functional. If you are also interested in the PS2 RC Transmitter Idea please
let me know (Tony Odin) and I can send you the sketches to begin working on.
(Preferably more advanced AVR/Atmel/Arduino Programmers as incorporating a
wireless aspect has proven to be pretty tricky for beginners) I look forward 
to hearing from you guys! Leave me some comments! I have : 
Tft LCD (144SPI),16x2 Char LCD, Lights, Buzzers, ESCs, RF24s(NRF24l01 2.4Ghz)
Brushless Outrunners, IR devices/remotes; almost any component off eBay haha.
If you want a tutorial on one of these items Let me know which component. I
am more than happy to share what I know with you guys!! 

Thanks for reading! Goodluck with the PS2 Controller Project! 
			Tony Odin 2015




 

	  
		      
